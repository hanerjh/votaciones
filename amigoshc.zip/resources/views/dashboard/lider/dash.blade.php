@extends('../../layout.layoutlider')
@section('titulo','Dashboard')
@section('content')

        <!-- Begin Page Content -->
        <div class="container-fluid">

      
          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total de usuarios en el sistema</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$cant_usu_registrado}}</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
   <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">cantidad de usuarios que he registrados</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$cant_usu_reg_lider}}</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

           
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total de Votos: <span class="font-weight-bold text-gray-800">{{$total_votos}}</span> </div>
                     
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">                          
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
                        </div>
                        <div class="col">
                          <div class="progress progress-sm mr-2">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Cuantos de mis usuarios han votado</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{$total_votos_usu_lider}}</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Cuantos de mis usuarios no han votado</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      <a href="/l_usuariosdeliderfaltantesporvotar/{{ Session::get('iduser')}}"> {{$faltantes_votos}}</a> 
                      </div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-comments fa-2x text-gray-300"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total de usuarios por votar</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                    <a href="/l_totalvotosfaltantes"> {{$total_votos_faltantes}}</a> 
                    </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>



          


          </div>

       

         
          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
           <!-- <div class="col-xl-8 col-lg-7">
              <div class="card shadow mb-4">
                
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Votación por zonas</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
               
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
              </div>
            </div>-->

            



            <div class="col-xl-8 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Votacion por Zonas</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-area">
                    <div class="chart-container" style="position: relative; height:40vh; width:40vw">
                      <canvas id="myChart"></canvas>
                  </div>
                  </div>
                </div>
              </div>
            </div>


            
            <!-- Pie Chart -->
            <div class="col-xl-4 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Cantidad de puestos por zonas</h6>
              
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-pie">
                    <ul class="list-unstyled">
                      @foreach ($total_puestos_zonas as $zona)
                    <li>
                      
                      <a href="/puestos_por_zonas/{{ $zona->idzona}}"><span class="badge badge-primary badge-pill">{{$zona->cantidad}}</span> </a> Puestos de votación en la <b> {{$zona->zona}} </b>

                     </li>

                      @endforeach
                      
                     
                    </ul>  
                      
                  </div>
                </div>
              </div>
            </div>
            <!-- Cantidad de registro por lideres-->
            <div class="col-lg-4 mb-4">
                  <div class="card shadow mb-4">
                      <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Cantidad de registro por lideres</h6>
                      </div>
                      <div class="card-body">
                          @foreach ($total_usu_reg_por_lideres as $lideres)
                            <h4 class="small font-weight-bold">
                              <a href="l_usuarioslider/{{$lideres->id}}">{{ $lideres->lider }} </a><small class="text-secundary"> - {{$lideres->cantidad}} /40  </small>
                              <span class="float-right"> {{ ($lideres->cantidad *100)/40}}%</span>
                            </h4>
                            <div class="progress mb-4">
                              <div class="progress-bar " role="progressbar" style="width: {{ ($lideres->cantidad *100)/40}}%" aria-valuenow="{{ $lideres->cantidad }}" aria-valuemin="0" aria-valuemax="40"></div>
                            </div>
                          @endforeach
                      
                      </div>
                    </div>
              </div>


              <!-- Pie Chart -->
            <div class="col-xl-4 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-pie pt-4 pb-2">
                    <canvas id="myPieChart"></canvas>
                  </div>
                  <div class="mt-4 text-center small">
                    <span class="mr-2">
                      <i class="fas fa-circle text-primary"></i> Direct
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle text-success"></i> Social
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle text-info"></i> Referral
                    </span>
                  </div>
                </div>
              </div>
            </div>
              
          </div>

         
         
          
        </div>
        <!-- /.container-fluid -->

        
        @endsection


        @section('script')
        @php
        //OBTENEMOS LOS DATOS DESDE EL CONTROLADOR PARA LLENAR EL CHART
        $label=array_column($voto_por_zonas->toArray(),'zona');
        $data=array_column($voto_por_zonas->toArray(),'cantidad');
        $dat=array_column($total_puestos_zonas->toArray(),'zona');
       
          //dd(array_column($v,'zona'));
        @endphp
        <script>
          var ctx = document.getElementById('myChart');
          var myChart = new Chart(ctx, {
              type: 'bar',
              data: {
                  labels: <?php echo json_encode($label); ?> ,
                  datasets: [{
                      label: 'Numero de votos por zonas',
                      data: <?php echo json_encode($data); ?> ,
                      backgroundColor: [
                          'rgba(255, 99, 132, 0.2)',
                          'rgba(54, 162, 235, 0.2)',
                          'rgba(255, 206, 86, 0.2)',
                          'rgba(75, 192, 192, 0.2)',
                          'rgba(153, 102, 255, 0.2)',
                          'rgba(255, 159, 64, 0.2)'
                      ],
                      borderColor: [
                          'rgba(255, 99, 132, 1)',
                          'rgba(54, 162, 235, 1)',
                          'rgba(255, 206, 86, 1)',
                          'rgba(75, 192, 192, 1)',
                          'rgba(153, 102, 255, 1)',
                          'rgba(255, 159, 64, 1)'
                      ],
                      borderWidth: 1
                  }]
              },
              options: {
                  scales: {
                      yAxes: [{
                          ticks: {
                              beginAtZero: true
                          }
                      }]
                  }
              }
          });
          </script>
        @endsection