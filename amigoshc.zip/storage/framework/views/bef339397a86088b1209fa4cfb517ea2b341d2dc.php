<?php $__env->startSection('titulo','PUESTOS POR ZONAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">

   
    <p>Listado puestos por zonas</p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>                 
                    <th scope="col">PUESTO DE VOTOS</th>                    
                    <th scope="col">CANTIDAD DE VOTOS</th>                   
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $total_puestos_zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th> 
                            <td><?php echo e($puesto->zona); ?></td>                          
                            <td><?php echo e($puesto->nombre_puesto); ?></td>                           
                            <td></td> 
                                                                               
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  
                </tbody>
              </table>
     
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>