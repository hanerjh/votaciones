<?php $__env->startSection('titulo','RESTABLECER CONTRASEÑA'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-6">
<p>Para restablecer la contraseña de un usuario, por favor ingresar su número de documento y le será enviado al correo la nueva contraseña</p>
<form class="form-inline" action="l_cambiar_password/" method="POST"> 
    <?php echo csrf_field(); ?>  
    <div class="form-group mx-sm-6 mb-2">      
      <input type="text" name="documento" class="form-control" id="inputPassword2" placeholder="Ingresar Documento">
    </div>
    <button type="submit" class="btn btn-primary mb-2 ml-2">Enviar</button>
  </form>
  <?php if(session()->has('msjpass')): ?>
  <div class="alert alert-primary" role="alert">
   <?php echo e(session('msjpass')); ?>

  </div>
  <?php endif; ?>
  <?php echo $errors->first('mensaje','<small class="text-danger">:message</small>'); ?>

 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../layout.layoutlider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>