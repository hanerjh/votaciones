
mensaje enviado
<?php echo e($mensaje); ?>