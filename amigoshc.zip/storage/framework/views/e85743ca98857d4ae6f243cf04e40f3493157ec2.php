<?php $__env->startSection('titulo','REGISTRAR MESA'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-7" >
      
<form action="/registrarmesa" method="POST" >
    <div class="form-row">
            <div class="col-12 ">
                    <legend class="text-light bg-dark px-2">Informacion Registro de Mesa de votación</legend>
                 </div>
    <?php echo csrf_field(); ?>
        <div class="form-group col-md-4">
                <label for="inputState">Region</label>
                <select id="inputState"   class="form-control" v-on:Change="onChangeregion($event)"  v-model="selectedregion">          
                  <option selected>Seleccione...</option>
                  <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($region->idregiones); ?>"><?php echo e($region->region); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </select>
              </div>

              <div class="form-group col-md-4">
                    <label for="inputState">Departamento</label>
                    <select id="inputState"   class="form-control" v-on:change="cargarMunicipioPersona($event)" >
                      <option selected>Seleccione...</option>
                     
                    <option v-for="departamento in departamentos" :value="departamento.coddepartamentos">{{departamento.departamento}}</option>
                       
                    </select>
                  </div>

     
      
          <div class="form-group col-md-4">
              <label for="inputState"> Municipio</label>
              <select id="inputState"   class="form-control" v-on:Change="cargarPuestosVotaciongeneral($event)">
                <option selected>Seleccione...</option>
                <option v-for="mpersona in municipiosPersona" :value="mpersona.codmunicipio">{{mpersona.municipio}}</option>
              </select>
            </div>
      

            
    <div class="form-group col-md-6">
        <label for="inputState">* Puesto de Votación</label>
        <select id="inputState"  name="puesto" class="form-control" v-on:Change="cargarmesas($event)" v-model="selectedpuesto">
          <option selected>Seleccione...</option>
          <option v-for="puesto in puestovotaciones" v-bind:value="puesto.idpuesto_votacion">{{puesto.nombre_puesto}}</option>
        </select>
      </div>

         
      
      
      
        <div class="form-group col-md-6">
          <label for="inputAddress2">* Mesa de Votacion</label>
          <input type="text" name="mesa" class="form-control" id="inputAddress2" placeholder="Mesa">
        </div>
       
      </div>
      <button type="submit" class="btn btn-primary btn-block">Registrar</button>
   
    
</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>