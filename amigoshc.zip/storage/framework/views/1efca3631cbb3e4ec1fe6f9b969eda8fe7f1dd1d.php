<?php $__env->startSection('titulo','REGISTRAR LUGAR DE VOTACIÓN'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-8" >
      
<form action="registrarpuestovotacion/" method="POST" >
    <div class="form-row">
            <div class="col-12 ">
                    <legend class="text-light bg-dark px-2">Informacion Registro de puesto de votación</legend>
                 </div>
    <?php echo csrf_field(); ?>
        <div class="form-group col-md-4">
                <label for="inputState">Region</label>
                <select id="inputState"   class="form-control" v-on:Change="onChangeregion($event)"  v-model="selectedregion">          
                  <option selected>Seleccione...</option>
                  <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($region->idregiones); ?>"><?php echo e($region->region); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </select>
              </div>

              <div class="form-group col-md-4">
                    <label for="inputState">Departamento</label>
                    <select id="inputState"   class="form-control" v-on:change="cargarMunicipioPersona($event)" >
                      <option selected>Seleccione...</option>
                     
                    <option v-for="departamento in departamentos" :value="departamento.coddepartamentos">{{departamento.departamento}}</option>
                       
                    </select>
                  </div>

     
      
          <div class="form-group col-md-4">
              <label for="inputState">* Municipio</label>
              <select id="inputState"  name="municipio" class="form-control" v-on:change="cargarcomunasPersona($event)">
                <option selected>Seleccione...</option>
                <option v-for="mpersona in municipiosPersona" :value="mpersona.codmunicipio">{{mpersona.municipio}}</option>
              </select>
              <?php echo $errors->first('municipio','<small class="text-danger">:message</small>'); ?>

            </div>
      
            <div class="form-group col-md-4">
              <label for="inputState">Comuna</label>
              <select id="inputState"  name="comuna" class="form-control" v-model="idcomuna" v-on:change="cargarBarrios($event)">
                <option value="">Seleccione...</option>
              <option v-for="comuna in lista[0]"  v-bind:value="comuna.idcomuna">{{comuna.comuna}}</option>
              </select>
              <?php echo $errors->first('comuna','<small class="text-danger">:message</small>'); ?>

            </div>
      
        <div class="form-group col-md-8">
        <label for="inputAddress">Barrio</label>
         <select id="inputState"  name="barrio" class="form-control">
                <option value="">Seleccione...</option>
              <option v-for="barrio in barrios"  v-bind:value="barrio.idbarrio">{{barrio.barrio}}</option>
        </select>
        </div>
       
        <div class="form-group col-md-4">
          <label for="inputAddress">zonas*</label>
           <select id="inputState"  name="zona" class="form-control">
                  <option value="">Seleccione...</option>
                <option v-for="zona in zonas"  v-bind:value="zona.idzona">{{zona.zona}}</option>
          </select>
          <?php echo $errors->first('zona','<small class="text-danger">:message</small>'); ?>

          </div>

        <div class="form-group col-md-4">
          <label for="inputAddress2">* puesto de Votacion</label>
          <input type="text" name="lugarvotacion" class="form-control" id="inputAddress2" placeholder="puesto de votacion">
          <?php if($errors->has('lugarvotacion')): ?>         
            <small class="text-danger"><?php echo e($errors->first('lugarvotacion')); ?></small>  
          <?php endif; ?>
        </div>
        <div class="form-group col-md-4">
                <label for="inputAddress2">* Dirección</label>
                <input type="text" name="direccion" class="form-control"  placeholder="Direccón">
                <?php if($errors->has('direccion')): ?>         
                <small class="text-danger"><?php echo e($errors->first('direccion')); ?> </small>  
               <?php endif; ?>
              </div>
          
      </div>
      <button type="submit" class="btn btn-primary btn-block">Registrar</button>
   
    
</form>

</div>

<div class="col-4">
  <?php if(session()->has('msj')): ?>
  <div class="alert alert-success" role="alert">
   <?php echo e(session('msj')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>