<?php $__env->startSection('titulo',''); ?>
<?php $__env->startSection('content'); ?>
<div class="col-6">
<h2>CAMBIA TU CONTRASEÑA</h2>
  <form class="form-inline" action="l_change_password/" method="POST"> 
    <?php echo csrf_field(); ?>  
    <div class="form-group mx-sm-6 mb-2">      
      <input type="password" name="pass" class="form-control" id="inputPassword2" placeholder="Nueva contraseña">
    </div>
    <button type="submit" class="btn btn-primary mb-2 ml-2">Cambiar</button>
  </form>
  <?php if(session()->has('msj')): ?>
  <div class="alert alert-primary" role="alert">
   <?php echo e(session('msj')); ?>

  </div>
  <?php endif; ?>
  <?php echo $errors->first('mensaje','<small class="text-danger">:message</small>'); ?>

 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../layout.layoutlider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>