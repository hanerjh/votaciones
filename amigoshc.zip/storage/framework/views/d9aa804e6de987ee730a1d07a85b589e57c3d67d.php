<?php $__env->startSection('titulo','Actualizar usuario'); ?>
<?php $__env->startSection('content'); ?>



<div class="col-md-8">

<form action="/l_usuario/<?php echo e($usuario->idpersona); ?>/" method="POST" >
  <!--metodo para actualizar informacion-->
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
  <div class="form-row">
      <div class="col-12 ">
          <legend class="text-light bg-dark px-2">Informacion personal</legend>
       </div>
       <div class="form-group col-md-3">
          <label for="inputEmail4">Tipo de usuario</label>
          <select id="tpusuario"  name="tpusuario" class="form-control" data-tpusu="<?php echo e($usuario->fktipousuario); ?>" value="">
              <option>Selecciones</option>
              <option value="1">Amigo</option>
              <option value="2">Lider</option>
            </select>
       </div>
      <div class="form-group col-md-3">
          <label for="inputEmail4">* Documento</label>
          
      <input type="text" name="documento" class="form-control" value="<?php echo e($usuario->documento); ?>" placeholder="Cedula">
            <?php if($errors->has('documento')): ?>         
               <small class="text-danger"><?php echo e($errors->first('documento')); ?> </small>  
            <?php endif; ?>
           
        </div>

      <div class="form-group col-md-3">
        <label for="inputEmail4">* Nombre</label>
        <input type="text"  name="nombre" class="form-control"  placeholder="Ingresar nombre"  value="<?php echo e($usuario->nombre); ?>">
        <?php if($errors->has('nombre')): ?>         
          <small class="text-danger"><?php echo e($errors->first('nombre')); ?></small>  
        <?php endif; ?>
      </div>
      <div class="form-group col-md-3">
        <label for="inputPassword4">* Apellido</label>
        <input type="text"  name="apellido" class="form-control" id="inputPassword4" placeholder="Ingresar Apellido" value="<?php echo e($usuario->apellido); ?>">
        <?php if($errors->has('apellido')): ?>         
        <small class="text-danger"><?php echo e($errors->first('apellido')); ?></small>  
      <?php endif; ?>
      </div>
    </div>

<div class="form-row">
    <div class="form-group col-md-4">
        <label for="inputEmail4">Fecha de Nacimiento</label>
        <input type="date"  name="fechaNacimiento" class="form-control" value="<?php echo e($usuario->fechaNacimiento); ?>" placeholder="Fecha de nacimierto">
      </div>

      <div class="form-group col-md-8">
          <label for="inputEmail4">Genero</label>
          <select id="genero"  name="genero" class="form-control" data-id="<?php echo e($usuario->sexo); ?>" value="">
              <option>Selecciones</option>
              <option value="Hombre">Hombre</option>
              <option value="Mujer">Mujer</option>
            </select>
        </div>

  <div class="form-group col-md-7">
    <label for="inputEmail4">Email</label>
    <input type="email"  name="email" class="form-control" id="inputEmail4" placeholder="Email" value="<?php echo e($usuario->correo); ?>">
    <?php if($errors->has('email')): ?>         
          <small class="text-danger"><?php echo e($errors->first('email')); ?></small>  
        <?php endif; ?>
  </div>
  <div class="form-group col-md-5">
    <label for="inputPassword4">* Telefono/Celular</label>
    <input type="text"  name="telefono" class="form-control" id="inputPassword4" placeholder="telefono" value="<?php echo e($usuario->telefono); ?>">
    <?php if($errors->has('telefono')): ?>         
          <small class="text-danger"><?php echo e($errors->first('telefono')); ?></small>  
        <?php endif; ?>
  </div>


<div class="form-row">

  <div class="form-group col-md-4">
    <label for="inputState">Departamento</label>
  <select id="departamento"  name="departamento" data-dpt="<?php echo e($usuario->departamentos_coddepartamentos); ?>" class="form-control" v-on:change="cargarMunicipioPersona($event)">
        <option selected>Seleccione...</option>
      <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
    <option value="<?php echo e($departamento->coddepartamentos); ?>"><?php echo e($departamento->departamento); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>
  </div>

    <div class="form-group col-md-4">
        <label for="inputState">Municipio</label>
        <select id="municipio"  name="municipio" data-codmuni="<?php echo e($usuario->codmunicipio); ?>"  data-muni="<?php echo e($usuario->municipio); ?>" class="form-control" v-on:change="cargarcomunasPersona($event)">
          <option selected>Seleccione...</option>
          <option v-for="mpersona in municipiosPersona" :value="mpersona.codmunicipio">{{mpersona.municipio}}</option>
        </select>
      </div>


      <div class="form-group col-md-4">
        <label for="inputAddress">Barrio</label>
        <!--<input type="text"  class="form-control" id="inputAddress" v-model="inputbarrio"  placeholder="Cascajal, Transformacion...">-->
      <input type="hidden" id="hiddenbarrio"  data-barrioid="<?php echo e($usuario->idbarrio); ?>" name="barrio"  class="form-control" id="inputAddress" :value="idbarrio" v-on:keyup="">
      
        <component-list id="barriocomponet" data-barrio="<?php echo e($usuario->barrio); ?>" v-bind:lists="lista[1]" v-bind:input="inputbarrio"  v-on:itemidbarrio="idbarrio=$event"  v-on:itemidcomuna="idcomuna=$event"></component-list>
       <!-- {{idbarrio}} - {{idcomuna}}-->
        </div>

      <div class="form-group col-md-5">
        <label for="inputState">Comuna</label>
      <select id="comuna"  name="comuna" data-comunaid="<?php echo e($usuario->idcomuna); ?>" data-comuna="<?php echo e($usuario->comuna); ?>" class="form-control" v-model="idcomuna">
          <option value="">Seleccione...</option>
        <option v-for="comuna in lista[0]"  v-bind:value="comuna.idcomuna">{{comuna.comuna}}</option>
        </select>
      </div>

 

  <div class="form-group col-md-7">
    <label for="inputAddress2">* Direccion</label>
    <input type="text" name="direccion" class="form-control" id="inputAddress2" placeholder="1234 Main St" value="<?php echo e($usuario->direccion); ?>">
    <?php if($errors->has('direccion')): ?>         
    <small class="text-danger"><?php echo e($errors->first('direccion')); ?></small>  
  <?php endif; ?>
  </div>
</div>



 
<div class="form-row">
   <div class="col-12 ">
      <legend class="text-light bg-dark px-2">*Informacion de Lugar de votacion</legend>
   </div>
    
    <div class="form-group col-md-4">
        <label for="inputState">Region</label>
        <select id="inputState" name="region"  class="form-control" v-on:Change="onChangeregion($event)"  v-model="selectedregion">          
          <option selected>Seleccione...</option>
          <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($region->idregiones); ?>"><?php echo e($region->region); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </select>
        <?php if($errors->has('region')): ?>         
    <small class="text-danger"><?php echo e($errors->first('region')); ?></small>  
  <?php endif; ?>
      </div>
  <div class="form-group col-md-4">
    <label for="inputState">*Departamento</label>
    <select id="inputState" name="departamento_votacion"  class="form-control" v-on:Change="onChange($event)" v-model="itemlist" >
      <option selected>Seleccione...</option>
     
    <option v-for="departamento in departamentos" :value="departamento.coddepartamentos">{{departamento.departamento}}</option>
       
    </select>
    <?php if($errors->has('departamento_votacion')): ?>         
    <small class="text-danger"><?php echo e($errors->first('departamento_votacion')); ?></small>  
  <?php endif; ?>
  </div>

  <div class="form-group col-md-4">
      <label for="inputState">*Municipio</label>
      <select id="inputState"  name="municipio_votacion" class="form-control" v-on:Change="cargarPuestosVotacion($event)" v-model="selectedmunicipio">
        <option selected>Seleccione...</option>
      <option v-for="muni in municipios2" :value="muni.codmunicipio">{{muni.municipio}}</option>         
           
      </select>
      <?php if($errors->has('municipio_votacion')): ?>         
      <small class="text-danger"><?php echo e($errors->first('municipio_votacion')); ?></small>  
    <?php endif; ?>
    </div>
   

    <div class="form-group col-md-6">
        <label for="inputState">*Puesto de Votación</label>
        <select id="puesto"  name="puesto" data-puestoid="<?php echo e($usuario->idpuesto_votacion); ?>" data-puesto="<?php echo e($usuario->nombre_puesto); ?>" class="form-control" v-on:Change="cargarmesas($event)" v-model="selectedpuesto">
          <option selected>Seleccione...</option>
          <option v-for="puesto in puestovotaciones" v-bind:value="puesto.idpuesto_votacion">{{puesto.nombre_puesto}}</option>
        </select>
        <?php if($errors->has('puesto')): ?>         
        <small class="text-danger"><?php echo e($errors->first('puesto')); ?></small>  
      <?php endif; ?>
      </div>

      <div class="form-group col-md-2">
          <label for="inputAddress2">*Mesa </label>
            <select id="mesa" name="mesa" data-mesaid="<?php echo e($usuario->idmesa); ?>" data-mesa="<?php echo e($usuario->mesa); ?>" class="form-control">
            <option selected>Seleccione...</option>
            <option v-for="mesa in mesas" v-bind:value="mesa.idmesa">{{mesa.mesa}}</option>
          </select>

          <?php if($errors->has('mesa')): ?>         
          <small class="text-danger"><?php echo e($errors->first('mesa')); ?></small>  
        <?php endif; ?>
        </div>

        
    <div class="form-group col-md-4">
        <label for="inputState">Consultar Mesa Votación</label>
        <a href="https://wsp.registraduria.gov.co/censo/consultar/"  class="btn btn-primary btn-block" target="_blank">Ir a Registraduria</a>
      </div>
     
</div>


<button type="submit" class="btn btn-primary btn-block">Actualizar</button>
</form>

</div>
</div>

<div class="col-md-4">
  <?php if(session()->has('msj')): ?>
  <div class="alert alert-success" role="alert">
       <?php echo e(session('msj')); ?>

    </div>
  <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
       <h4>Por favor rellenar los campos que hacen falta.</h4>
       <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      </div>
  
    <?php endif; ?>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
       $( document ).ready(function() {
           var $genero= $("#genero").data('id');
           var $tpusuario= $("#tpusuario").data('tpusu');
           var $dpt= $("#departamento").data('dpt');
           var $muni= $("#municipio").data('muni');
           var $codmuni= $("#municipio").data('codmuni');
           var $barrioid=$("#hiddenbarrio").data('barrioid');
           var $barrio=$("#barriocomponet").data('barrio');
           var $comuna=$("#comuna").data('comuna');
           var $comunaid=$("#comuna").data('comunaid');
           var $puestoid=$("#puesto").data('puestoid');
           var $puesto=$("#puesto").data('puesto');
           var $mesaid=$("#mesa").data('mesaid');
           var $mesa=$("#mesa").data('mesa');

           $("#genero").val($genero);
           $("#tpusuario").val($tpusuario);
           $("#departamento").val($dpt);
           $("#municipio").append("<option value='"+$codmuni+"' selected>"+ $muni +"</option>");
           $("#hiddenbarrio").val($barrioid);
           $("#barriocomponet #inputAddress").val($barrio);
           $("#comuna").append("<option value='"+$comunaid+"' selected>"+ $comuna +"</option>");
           $("#puesto").append("<option value='"+$puestoid+"' selected>"+ $puesto +"</option>");
           $("#mesa").append("<option value='"+$mesaid+"' selected>"+ $mesa +"</option>");

          
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layoutlider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>