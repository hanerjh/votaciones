<?php $__env->startSection('titulo','VOTOS POR ZONAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
   
   
    <p>Listado de usuarios regitrados por la paginas web </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Telefono</th>                   
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $registroweb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                            <td> <?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido); ?></td>
                            <td><?php echo e($usuario->telefono); ?></td>                            
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
              </table>
     
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>