<?php $__env->startSection('titulo','REGISTRO DE USUARIOS POR LIDER'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <?php
        //dd($usu_reg_by_lider->first());
    ?>
    <?php if(is_null($usu_reg_by_lider->first())): ?>
      <p>No tienes usuarios registrados para la campaña</p>
    <?php else: ?>
    <p>Listado de usuarios regitrados por el/la lider <strong><?php echo e($usu_reg_by_lider[0]->lider); ?></strong> </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Puesto de votación</th>
                    <th scope="col">Mesa de votación</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usu_reg_by_lider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                            <td><?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido); ?></td>
                            <td><?php echo e($usuario->telefono); ?></td>
                            <td><?php echo e($usuario->nombre_puesto); ?></td>
                            <td><?php echo e($usuario->mesa); ?></td>
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
              </table>
       <?php endif; ?>
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layoutlider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>