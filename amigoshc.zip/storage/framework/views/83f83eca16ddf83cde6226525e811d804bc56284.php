<?php $__env->startSection('titulo','REGISTRAR NOTICIA'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-7" >
      
  <form action="/noticias" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleFormControlFile1">Imagen</label>
      <input type="file" name="archivo">
    </div>
    <div class="form-group">
      <label for="exampleFormControlInput1">Titulo</label>
      <input type="text" name="titulo" class="form-control" id="titulo" placeholder="Titulo de la noticia">
    </div>
    
   
    <div class="form-group">
      <label for="exampleFormControlTextarea1">Contenido</label>
      <textarea name="contenido" class="form-control" id="editor" rows="3"></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-block">Registrar</button>
  </form>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'editor' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>