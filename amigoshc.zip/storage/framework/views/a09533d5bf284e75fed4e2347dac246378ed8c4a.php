<?php $__env->startSection('titulo','VOTOS POR PUESTOS'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
   <?php
       $cantidad=0;
   ?>
   
    <p>Listado de votación por puestos </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>                 
                    <th scope="col">PUESTO DE VOTOS</th>                    
                    <th scope="col">CANTIDAD DE VOTOS</th>                   
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $voto_por_puesto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>                           
                            <td><?php echo e($puesto->nombre_puesto); ?></td>                           
                            <td><?php echo e($puesto->cantidad); ?></td> 
                                <?php
                                $cantidad+=$puesto->cantidad;
                              ?>                                                   
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td colspan="2"><b>TOTAL DE VOTOS CONFIRMADOS POR PUESTOS</b></td>
                    <td> <b><?php echo e($cantidad); ?></b></td>
                  </tr>
                  
                </tbody>
              </table>
     
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layoutlider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>