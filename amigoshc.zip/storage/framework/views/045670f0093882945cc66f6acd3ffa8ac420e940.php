<?php $__env->startSection('titulo','VOTOS POR MESAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
  <?php
  $cantidad=0;
?>
   
    <p>Listado de votación por mesas </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">ZONA DE VOTACÓN</th>
                    <th scope="col">PUESTO DE VOTOS</th> 
                    <th scope="col">MESA DE VOTOS</th> 
                    <th scope="col">CANTIDAD DE VOTOS</th>                   
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $voto_por_mesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                            <td><?php echo e($mesa->zona); ?></td>
                            <td><?php echo e($mesa->nombre_puesto); ?></td> 
                            <td><?php echo e($mesa->mesa); ?></td>
                            <td><?php echo e($mesa->cantidad); ?></td>  
                            <?php
                            $cantidad+=$mesa->cantidad;
                          ?>                           
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td colspan="4"><b>TOTAL DE VOTOS CONFIRMADOS POR MESAS</b></td>
                      <td> <b><?php echo e($cantidad); ?></b></td>
                    </tr>
                  
                </tbody>
              </table>
     
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>