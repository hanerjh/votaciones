<?php $__env->startSection('titulo','VOTOS POR ZONAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
   
   
    <p>LISTADO DE LIDERES  </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Lider</th>
                    <th scope="col">Cantidad de usuarios regitrados</th>                   
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $total_usu_reg_por_lideres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lideres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                            <td> <?php echo e($lideres->lider); ?> </td>
                            <td><a href="usuarioslider/<?php echo e($lideres->id); ?>"><?php echo e($lideres->cantidad); ?></a></td>                            
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
              </table>
     
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>