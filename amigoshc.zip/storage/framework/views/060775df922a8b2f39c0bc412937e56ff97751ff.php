<?php $__env->startSection('titulo','ASIGNAR ROLES'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12">
<h1 class="h3 mb-2 text-gray-800">Tables</h1>
<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>
<?php
$lista="[";    
?>

<?php $__currentLoopData = $tpusuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
 $lista  = $lista."{value:". "'".$item->idtipousuario."'" .", text:". "'".$item->tipousuario."'"."},";
    
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php
    $lista=$lista."]";  
?>
<?php echo e($lista); ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Documento</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Direccion</th>
            <th>Correo</th>
            <th>Telefono</th>
            <th>Tipo Usuario</th>
            <th>Puesto votacion</th>
            <th>Mesa</th>
            <th>editar</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>Documento</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Direccion</th>
            <th>Correo</th>
            <th>Telefono</th>
            <th>Tipo Usuario</th>
            <th>Puesto votacion</th>
            <th>Mesa</th>
            <th>editar</th>
          </tr>
        </tfoot>
        <tbody>
       
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td   class="iteminput" data-name="documento" data-type="text" data-pk="<?php echo e($persona->idpersona); ?>">
                     <?php echo e($persona->documento); ?>

                </td>
              <td  class="iteminput" data-name="nombre" data-type="text" data-pk="<?php echo e($persona->idpersona); ?>"><?php echo e($persona->nombre); ?></td>  
                 <td  class="iteminput" data-name="apellido" data-type="text" data-pk="<?php echo e($persona->idpersona); ?>" ><?php echo e($persona->apellido); ?></td>                 
                 <td  class="iteminput" data-name="direccion"  data-type="text" data-pk="<?php echo e($persona->idpersona); ?>" ><?php echo e($persona->direccion); ?></td>
                 <td  class="iteminput" data-name="correo" data-type="text" data-pk="<?php echo e($persona->idpersona); ?>" ><?php echo e($persona->correo); ?></td>
                 <td  class="iteminput" data-name="telefono"  data-type="text" data-pk="<?php echo e($persona->idpersona); ?>" ><?php echo e($persona->telefono); ?></td>
              <td  class="itemselect" data-name="fktipousuario" data-type="select" data-pk="<?php echo e($persona->idpersona); ?>" data-source="<?php echo e($lista); ?>" data-value="<?php echo e($persona->fktipousuario); ?>" ><?php echo e($persona->tipousuario); ?></td>
              <td><?php echo e($persona->nombre_puesto); ?></td>
              <td><?php echo e($persona->mesa); ?></td>
              <td><a class="btn btn-small btn-info" href="/usuario/<?php echo e($persona->idpersona); ?>/edit">Edit</a></td>
            </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
         
        </tbody>
      </table>
    </div>
  </div>
</div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>