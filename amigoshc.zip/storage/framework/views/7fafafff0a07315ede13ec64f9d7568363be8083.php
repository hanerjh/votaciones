<?php $__env->startSection('titulo','Campaña'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-8" >
      
    <form action="campaña/" method="POST" >
        <div class="form-row">
                <div class="col-12 ">
                        <legend class="text-light bg-dark px-2">Informacion Registro de Campaña</legend>
                     </div>
        <?php echo csrf_field(); ?>
            <div class="form-group col-md-4">
                    <label for="inputState">Tipo de elección</label>
                    <select name="tipoeleccion" id="inputState"   class="form-control">          
                      <option selected>Seleccione...</option>
                    <?php $__currentLoopData = $tipoelecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($eleccion->idtipoeleccion); ?>"><?php echo e($eleccion->eleccion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </select>
                  </div>
        
          
    
            <div class="form-group col-md-6">
              <label for="inputAddress2">* Nombre de la Campaña</label>
              <input type="text" name="campaña" class="form-control" id="inputAddress2" placeholder="Campaña">
              <?php if($errors->has('campaña')): ?>         
                <small class="text-danger"><?php echo e($errors->first('campaña')); ?></small>  
              <?php endif; ?>
            </div>
            <div class="form-group col-md-2">
                    <label for="inputAddress2">* Año</label>
                    <input type="text" name="año" class="form-control"  placeholder="Año">
                    <?php if($errors->has('año')): ?>         
                    <small class="text-danger"><?php echo e($errors->first('año')); ?> </small>  
                   <?php endif; ?>
            </div>

            <div class="form-group col-md-4">
                <label for="inputAddress2">* Fecha de Cierre de Campaña</label>
                <input type="date" name="fecha" class="form-control" >
                <?php if($errors->has('fecha')): ?>         
                <small class="text-danger"><?php echo e($errors->first('fecha')); ?> </small>  
               <?php endif; ?>
              </div>
              
          </div>
          <button type="submit" class="btn btn-primary btn-block">Registrar</button>
       
        
    </form>
    
    </div>
    
    <div class="col-4">
      <?php if(session()->has('msj')): ?>
      <div class="alert alert-success" role="alert">
       <?php echo e(session('msj')); ?>

      </div>
      <?php endif; ?>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>