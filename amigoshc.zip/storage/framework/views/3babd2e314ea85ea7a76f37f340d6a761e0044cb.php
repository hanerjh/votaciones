<?php $__env->startSection('titulo','TOTAL PERSONAS QUE HACEN FALTA POR VOTAR'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <?php
        //dd($usu_reg_by_lider->first());
    ?>
    <?php if(is_null($usu_reg_by_lider->first())): ?>
      <p>No tiene usuarios registrados para la campaña</p>
    <?php else: ?>
    <p>Listado general de usuarios en el sistema que no han confirmado su voto </p>
        <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Lider</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Puesto de votación</th>
                    <th scope="col">Mesa de votación</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usu_reg_by_lider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                            <td><div class="pl-2 bg-dark text-white"><i class="fas fa-user-tie"></i> <strong><?php echo e($usuario->lider); ?> <?php echo e($usuario->apellidolider); ?></strong></div> </td>
                            <td><a class="" href="/usuario/<?php echo e($usuario->idpersona); ?>/edit"><?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido); ?></a></td>                    
                            <td><?php echo e($usuario->telefono); ?></td>
                            <td><?php echo e($usuario->nombre_puesto); ?></td>
                            <td><?php echo e($usuario->mesa); ?></td>
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
              </table>
       <?php endif; ?>
</div>

     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>